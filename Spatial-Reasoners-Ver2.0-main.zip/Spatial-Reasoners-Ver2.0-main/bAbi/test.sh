
#sbatch /scratch/jl13072/Spatial-Reasoners-Ver2.0/bAbi/t5-3b.sbatch
